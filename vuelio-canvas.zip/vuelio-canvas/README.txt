=== Vuelio Canvas ===
Plugin Name: Vuelio Canvas
Contributors: Vuelio
Tags: Vuelio, canvas, social wall, pr, releases
Requires at least: 3.8
Tested up to: 4.6.1
Stable tag: master

== Description ==
This plugin allows a user to insert a Vuelio Canvas into their WYSIWYG editor and it will render on the front end of the website.

The Canvas is hosted in an iframe which is set to be fully responsive.
